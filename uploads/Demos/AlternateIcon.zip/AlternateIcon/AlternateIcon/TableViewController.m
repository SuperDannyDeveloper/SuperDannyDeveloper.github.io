//
//  TableViewController.m
//  AlternateIcon
//
//  Created by SuperDanny on 2017/7/4.
//  Copyright © 2017年 SuperDanny. All rights reserved.
//

#import "TableViewController.h"

@interface TableViewController ()

@property (strong, nonatomic) NSArray *iconArr;

@end

@implementation TableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _iconArr = @[@"icon01",
                 @"icon02",
                 @"icon03",
                 @"icon04",
                 @"icon05",
                 @"icon06",
                 @"icon07"];
}

- (void)changeIconButtonClick:(NSUInteger)index {
    if ([UIApplication sharedApplication].supportsAlternateIcons) {
        NSLog(@"你可以更换icon");
        [[UIApplication sharedApplication] setAlternateIconName:_iconArr[index] completionHandler:^(NSError * _Nullable error) {
            if (!error) {
                NSLog(@"成功更换为%@",_iconArr[index]);
            }else{
                NSLog(@"error:%@",error);
            }
        }];
    } else {
        NSLog(@"非常抱歉，你不能更换icon");
        return;
    }
}

- (IBAction)backToPrimaryIconAction:(id)sender {
    if ([UIApplication sharedApplication].alternateIconName != nil) {
        //已经被替换掉了图标
        [[UIApplication sharedApplication] setAlternateIconName:nil completionHandler:^(NSError * _Nullable error) {
            if (!error) {
                NSLog(@"成功还原图标");
            } else {
                NSLog(@"error:%@",error);
            }
        }];
    }
}

#pragma mark - Table view delegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self changeIconButtonClick:indexPath.row];
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _iconArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    cell.imageView.image = [UIImage imageNamed:_iconArr[indexPath.row]];
    cell.textLabel.text = _iconArr[indexPath.row];
    return cell;
}


@end
